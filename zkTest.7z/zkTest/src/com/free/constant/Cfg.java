package com.free.constant;

public class Cfg {
	public static final String ZK_CONNECTION_STRING = "192.168.10.63:2181"; //zk client url+port
	public static final String ZK_ROOT_PATH = "/zkRootPath"; //ZK_ROOT_PATH
	public static final String ZK_RMI_PATH = "/zkRmiPath"; //zkRmiPath
	 
}
