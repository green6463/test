package com.free.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * ���ݿ�����Լ��
 * @author tomsnail
 * @date 2015��4��3�� ����10:11:51
 */
public class TestMySQL {
	public static void main(String[] args) {
		boolean l=test("");
		System.out.println(l);
	}
	public static boolean test(String url){
		String driver = "com.mysql.jdbc.Driver"; //����������  
		//url = "jdbc:mysql://192.168.10.61:3306/dyxadmin?characterEncoding=utf8&useSSL=true"; //����MySQL���ݿ�  
	    String sqlUser = "root"; //���ݿ��˺�  
	    String sqlPasswd = "P@ssw0rd"; //������ݿ�����  
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs  = null;
        String sql = "select 0";
           try {
               Class.forName(driver);
               //conn = DriverManager.getConnection(url);
               conn = DriverManager.getConnection(url,sqlUser,sqlPasswd); 
               stmt = conn.createStatement();
               rs = stmt.executeQuery(sql);
               while (rs.next()) {
               }
               return true;
           } catch (SQLException e) {
               e.printStackTrace();
           } catch (Exception e) {
               e.printStackTrace();
           } finally {
               try {
                   if(rs!=null){
                       rs.close();
                   }
                   if(stmt!=null){
                       stmt.close();
                   }
                   if(conn!=null)
                       conn.close();
               } catch (SQLException e) {
                   e.printStackTrace();
               }

           }
       return false;
   }
}
