package com.free.mysql;

import com.free.zk.TestServer;

/**
 * ���ݿ����������
 * @author tomsnail
 * @date 2015��4��3�� ����10:11:51
 */
public class TestMain {
    
	private static TestServer testServer = new TestServer();

    public static void main(String[] args) {
        String url = "jdbc:mysql://192.168.10.61:3306/dyxadmin?characterEncoding=utf8&useSSL=true"; //����MySQL���ݿ�  
        boolean isOK = false;
        while(true){
            if(TestMySQL.test(url)){
                if(isOK){
                    
                }else{
                    testServer.createNode(url);//����znode
                }
                isOK = true;
            }else{
                isOK = false;
                testServer.deleteNode(url);//ɾ��znode
            }
            
            try {
                Thread.currentThread().sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}