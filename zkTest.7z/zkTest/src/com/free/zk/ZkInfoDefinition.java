package com.free.zk;

/**
 * zookeeper��Ϣ������
 * @author tomsnail
 * @date 2015��4��2�� ����6:49:13
 */
public class ZkInfoDefinition {
    
    public static final String PREFIX_ZK = "zookeeper";
    
    public static final String ZK_URL = "zkUrl";
    
    public static final String ZK_SESSION_TIMEOUT = "sessionTimeout";
    
    public static final String ZK_PATH = "zkPath";
    
    public static final String ZK_ENABLE = "zkEnable";

    public static String zkUrl="192.168.10.63:2181";
    
    public static int sessionTimeout = 30000;
    
    public static boolean isEnable = false;
    
    public static String zkPath = "/home/zookeeper";

    public String getZkUrl() {
        return zkUrl;
    }

    public void setZkUrl(String zkUrl) {
        this.zkUrl = zkUrl;
    }

    public int getSessionTimeout() {
        return sessionTimeout;
    }

    public void setSessionTimeout(int sessionTimeout) {
        this.sessionTimeout = sessionTimeout;
    }

    public String getZkPath() {
        return zkPath;
    }

    public void setZkPath(String zkPath) {
        this.zkPath = zkPath;
    }

    public ZkInfoDefinition(String zkUrl, int sessionTimeout, String zkPath) {
        super();
        this.zkUrl = zkUrl;
        this.sessionTimeout = sessionTimeout;
        this.zkPath = zkPath;
    }
    public ZkInfoDefinition(){
        
    }
}