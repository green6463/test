package com.free.zk;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerFactory;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooDefs;
import org.apache.zookeeper.ZooKeeper;
import org.apache.zookeeper.data.Stat;

import com.free.constant.Cfg;

/**
 * zookeeper�ͻ���
 * @author tomsnail
 * @date 2015��4��3�� ����10:11:51
 */
public class TestServer {
	 private static final Logger logger = Logger.getLogger(TestServer.class);

	    private static ZooKeeper zk;
	    
	    private String path;

	    //ͬ����
	    private Lock _lock = new ReentrantLock();
	    
	    // ���ڵȴ� SyncConnected �¼����������ִ�е�ǰ�߳�
	    private CountDownLatch latch = new CountDownLatch(1);
	    

	    public TestServer() {
	        zk = connectServer();
	        new Thread(new Runnable() {
	            @Override
	            public void run() {
	                while (true) {
	                    try {
	                        Thread.currentThread().sleep(3000);
	                    } catch (InterruptedException e) {
	                        e.printStackTrace();
	                    }
	                    //logger.info("check zk...");
	                    _lock.lock();
	                    if (zk != null) {
	                        if (zk.getState().isAlive()) {//FIXME   && zk.getState().isConnected()���Ǹ�������ǿ���ȥ��
	                               // && zk.getState().isConnected()) {
	                            //logger.info("zk is ok");
	                            _lock.unlock();
	                            continue;
	                        }
	                    }
	                    close();
	                    logger.info("reConnectServer ...");
	                    zk = connectServer();
	                    logger.info("reConnectServer ok");
	                    _lock.unlock();
	                }

	            }

	            private void close() {
	                if(zk!=null){
	                    try {
	                        zk.close();
	                    } catch (InterruptedException e) {
	                        e.printStackTrace();
	                    }
	                    zk = null;
	                }
	            }
	        }).start();
	    }



	    // ���� ZooKeeper ������
	    private ZooKeeper connectServer() {
	        ZooKeeper zk = null;
	        int sessionTimeout=30000;
	        try {

	            zk = new ZooKeeper(Cfg.ZK_CONNECTION_STRING,sessionTimeout, new Watcher() {//FIXME  ������������Ҫ����/ZK_CONNECTION_STRING//sessionTimeout
	                        @Override
	                        public void process(WatchedEvent event) {
	                            if (event.getState() == Event.KeeperState.SyncConnected) {
	                                latch.countDown(); // ���ѵ�ǰ����ִ�е��߳�
	                            }
	                        }
	                    });
	            latch.await(); // ʹ��ǰ�̴߳��ڵȴ�״̬
	        } catch (Exception e) {
	            logger.error("", e);
	        }
	        if (zk != null) {
	            try {
	                Stat stat = zk.exists(Cfg.ZK_ROOT_PATH, false);//FIXME   ZK_ROOT_PATH
	                if (stat == null) {
	                    String path = zk.create(Cfg.ZK_ROOT_PATH,"".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE,//FIXME   ZK_ROOT_PATH
	                            CreateMode.PERSISTENT); // ����һ����ʱ��������� ZNode
	                    logger.info("create zookeeper node ({})"+ path);
	                }
	                stat = zk.exists(Cfg.ZK_RMI_PATH, false);//FIXME   ZK_RMI_PATH
	                if (stat == null) {

	                    String path = zk.create(Cfg.ZK_RMI_PATH,"".getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE,//FIXME   ZK_RMI_PATH
	                            CreateMode.PERSISTENT); // ����һ����ʱ��������� ZNode
	                    logger.info("create zookeeper node ({})"+path);
	                }
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        return zk;
	    }

	    // ���� ZNode
	    public void createNode(String url) {
	        _lock.lock();
	        try {
	            byte[] data = url.getBytes();
	            path = zk.create(Cfg.ZK_RMI_PATH + "/", data,ZooDefs.Ids.OPEN_ACL_UNSAFE,//FIXME   ZK_RMI_PATH
	                    CreateMode.EPHEMERAL_SEQUENTIAL); // ����һ����ʱ��������� ZNode
	            logger.info("create zookeeper node ({} => {})"+ path+ url);
	            System.out.println(path+url);
	        } catch (Exception e) {
	            logger.error("", e);
	            e.printStackTrace();
	        }
	        _lock.unlock();
	    }
	    
	    public void deleteNode(String url){
	        _lock.lock();
	        try {
	            Stat stat = zk.exists(path, false);
	            if(stat!=null){
	                zk.delete(url, stat.getVersion());
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	        _lock.unlock();
	    }
}
