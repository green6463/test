package com.free.zk;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.log4j.Logger;
import org.apache.zookeeper.WatchedEvent;
import org.apache.zookeeper.Watcher;
import org.apache.zookeeper.ZooKeeper;

/**
 * zookeeper�ͻ���
 * @author tomsnail
 * @date 2015��4��3�� ����10:15:11
 */
public class ZkClient {

       private static final Logger logger = Logger.getLogger(ZkClient.class);
       
        // ���ڵȴ� SyncConnected �¼����������ִ�е�ǰ�߳�
        private CountDownLatch latch = new CountDownLatch(1);
     
        // ����һ�� volatile ��Ա���������ڱ������µ� RMI ��ַ�����ǵ��ñ��������ᱻ�����߳����޸ģ�һ���޸ĺ󣬸ñ�����ֵ��Ӱ�쵽�����̣߳�
        private volatile List<String> dataList = new ArrayList<String>();
     
        private Lock _lock = new ReentrantLock();
        
        private static  ZooKeeper zk;
        
        private String lbUrl;//FIXME
        
        
        public ZkClient(){
            //this(new BasicLBUrl());//FIXME
        }
        
        // ������
        public ZkClient(String lbUrl) {
            this.lbUrl = lbUrl;
            zk = connectServer(); // ���� ZooKeeper ����������ȡ ZooKeeper ����
            watchNode();
            new Thread(new Runnable() {
                
                @Override
                public void run() {
                    while (true) {
                        try {
                            Thread.currentThread().sleep(3000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        _lock.lock();
                        if (zk != null) {
                            if (zk.getState().isAlive()) {
                                   // && zk.getState().isConnected()) {//FIXME
                                _lock.unlock();
                                continue;
                            }
                        }
                        if(zk!=null){
                            try {
                                zk.close();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            zk = null;
                        }
                        zk = connectServer();
                        _lock.unlock();
                    }
                }
            }).start();
        }
     
        // ���� URL ����
        public String getUrl() {
            if (dataList!=null&&dataList.size()>0) {
               //return this.lbUrl.getUrl(dataList);//FIXME
            }
            return null;
        }
        
        public List<String> getUrls(){
            return dataList;
        }
     
        // ���� ZooKeeper ������
        private ZooKeeper connectServer() {
            ZooKeeper zk = null;
            try {
                zk = new ZooKeeper(ZkInfoDefinition.zkUrl, ZkInfoDefinition.sessionTimeout, new Watcher() {
                    @Override
                    public void process(WatchedEvent event) {
                        if (event.getState() == Event.KeeperState.SyncConnected) {
                            latch.countDown(); // ���ѵ�ǰ����ִ�е��߳�
                        }
                    }
                });
                latch.await(); // ʹ��ǰ�̴߳��ڵȴ�״̬
            } catch (Exception e) {
                logger.error("", e);
            }
            return zk;
        }
     
        // �۲� /registry �ڵ��������ӽڵ��Ƿ��б仯
        private void watchNode() {
            _lock.lock();
            if(zk!=null&&zk.getState().isAlive()){//&&zk.getState().isConnected()//FIXME
                
            }else{
                if(zk!=null){
                    try {
                        zk.close();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    zk = null;
                }
                zk = connectServer();
            }
            try {
                List<String> nodeList = zk.getChildren(ZkInfoDefinition.zkPath, new Watcher() {
                    @Override
                    public void process(WatchedEvent event) {
                        if (event.getType() == Event.EventType.NodeChildrenChanged) {
                            watchNode(); // ���ӽڵ��б仯�������µ��ø÷�����Ϊ�˻�ȡ�����ӽڵ��е����ݣ�
                        }
                    }
                });
                List<String> dataList = new ArrayList<String>(); // ���ڴ�� /registry �����ӽڵ��е�����
                for (String node : nodeList) {
                    byte[] data = zk.getData(ZkInfoDefinition.zkPath + "/" + node, false, null); // ��ȡ /registry ���ӽڵ��е�����
                    dataList.add(new String(data));
                   
                }
                logger.debug("node data: {}"+dataList);
                this.dataList = dataList;
            } catch (Exception e) {
                logger.error("", e);
            }
            _lock.unlock();
        }
     
        public static void main(String[] args) {
            ZkClient client = new ZkClient();
            System.out.println(client.getUrl());
        }
}