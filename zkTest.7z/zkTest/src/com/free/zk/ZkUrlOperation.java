package com.free.zk;

import java.util.List;

/**
 * ��zookeeper���URL���Ӳ�����
 * @author tomsnail
 * @date 2015��4��2�� ����6:56:06
 */
public class ZkUrlOperation {
    
    private static final ZkUrlOperation instance = new ZkUrlOperation();

    private static ZkInfoDefinition zkInfoDefinition;
    
    private static ZkClient zkClient;
    
    private static final byte[] _lock = new byte[0];
    
    private  ZkUrlOperation(){
        
    }
    
    public static ZkUrlOperation getInstance(){
        return instance;
    }
    
    public  void addZkInfoDefinition(ZkInfoDefinition zkInfoDefinition){
        ZkUrlOperation.zkInfoDefinition = zkInfoDefinition;
    }
    
    public  void addZkInfoDefinition(String key,String value){
        if(ZkUrlOperation.zkInfoDefinition==null){
            ZkUrlOperation.zkInfoDefinition = new ZkInfoDefinition();
        }
        if(key.contains(ZkInfoDefinition.ZK_PATH)){
            ZkUrlOperation.zkInfoDefinition.setZkPath(value);
        }
        if(key.contains(ZkInfoDefinition.ZK_SESSION_TIMEOUT)){
            ZkUrlOperation.zkInfoDefinition.setSessionTimeout(Integer.valueOf(value));;
        }
        if(key.contains(ZkInfoDefinition.ZK_URL)){
            ZkUrlOperation.zkInfoDefinition.setZkUrl(value);;
        }
        if(key.contains(ZkInfoDefinition.ZK_ENABLE)){
            ZkUrlOperation.zkInfoDefinition.isEnable = Boolean.valueOf(value);
        }
    }
    
    
    public String getUrl(){
        synchronized (_lock) {
            if(zkInfoDefinition.isEnable){
                if(zkClient==null){
                    zkClient = new ZkClient();
                }
                
                String url = zkClient.getUrl();
                return url;
            }else{
                return "";
            }
            
        }
        
        
    }
    
    public boolean isAvailUrl(String url){
        synchronized (_lock) {
            if(zkInfoDefinition.isEnable){
                if(zkClient==null){
                    zkClient = new ZkClient();
                }
                List<String> urls = zkClient.getUrls();
                for(int i=0;i<urls.size();i++){
                    if(url.equals(urls.get(i))){
                        return true;
                    }
                }
                return false;
            }
            return false;
            
        }
        
    }
    
    
    
}